/**
 * LabOS v2.0 — Lab Inventory Management System
 * Hospital LAN Server — Node.js + Express + SQLite
 *
 * New in v2.0:
 *  - Partial / adjusted quantity approvals
 *  - PDF report export (pdfkit)
 *  - Excel report export (exceljs)
 *  - Department management
 *  - Role-based permissions table
 *  - Enhanced audit log (tracks every change with old/new values)
 *  - Low-stock alerts endpoint
 *
 * Run:  node server.js
 * Open: http://<this-pc-ip>:3000
 */

const express     = require('express');
const Database    = require('better-sqlite3');
const bcrypt      = require('bcryptjs');
const jwt         = require('jsonwebtoken');
const cors        = require('cors');
const compression = require('compression');
const path        = require('path');
const os          = require('os');

// optional — graceful if not installed yet
let PDFDocument, ExcelJS;
try { PDFDocument = require('pdfkit');  } catch { PDFDocument = null; }
try { ExcelJS     = require('exceljs'); } catch { ExcelJS = null; }

const app        = express();
const PORT       = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'labos-hospital-secret-v2-change-me';

app.use(compression());
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ════════════════════════════════════════════════════════════
// DATABASE SETUP
// ════════════════════════════════════════════════════════════
const db = new Database(path.join(__dirname, 'data', 'labos.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
  CREATE TABLE IF NOT EXISTS departments (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT UNIQUE NOT NULL,
    code       TEXT UNIQUE NOT NULL,
    head       TEXT DEFAULT '',
    active     INTEGER DEFAULT 1,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS permissions (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    role        TEXT NOT NULL,
    resource    TEXT NOT NULL,
    can_view    INTEGER DEFAULT 1,
    can_create  INTEGER DEFAULT 0,
    can_edit    INTEGER DEFAULT 0,
    can_delete  INTEGER DEFAULT 0,
    can_approve INTEGER DEFAULT 0,
    UNIQUE(role, resource)
  );

  CREATE TABLE IF NOT EXISTS users (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT NOT NULL,
    email      TEXT UNIQUE NOT NULL,
    password   TEXT NOT NULL,
    role       TEXT NOT NULL DEFAULT 'staff',
    dept       TEXT NOT NULL DEFAULT 'General',
    phone      TEXT DEFAULT '',
    active     INTEGER NOT NULL DEFAULT 1,
    last_login TEXT DEFAULT NULL,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS inventory (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    name         TEXT NOT NULL,
    category     TEXT NOT NULL DEFAULT 'Consumables',
    dept         TEXT NOT NULL,
    qty          INTEGER NOT NULL DEFAULT 0,
    min_qty      INTEGER NOT NULL DEFAULT 0,
    unit         TEXT NOT NULL DEFAULT 'pcs',
    supplier     TEXT DEFAULT '',
    unit_cost    REAL DEFAULT 0,
    notes        TEXT DEFAULT '',
    last_updated TEXT DEFAULT (date('now')),
    created_at   TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS requests (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    item_name      TEXT NOT NULL,
    item_id        INTEGER DEFAULT NULL,
    qty_requested  INTEGER NOT NULL,
    qty_approved   INTEGER DEFAULT NULL,
    dept           TEXT NOT NULL,
    user_id        INTEGER NOT NULL,
    user_name      TEXT NOT NULL,
    notes          TEXT DEFAULT '',
    admin_notes    TEXT DEFAULT '',
    priority       TEXT DEFAULT 'Normal',
    status         TEXT NOT NULL DEFAULT 'pending',
    approved_by    TEXT DEFAULT NULL,
    approved_by_id INTEGER DEFAULT NULL,
    approval_date  TEXT DEFAULT NULL,
    reject_reason  TEXT DEFAULT NULL,
    created_at     TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS audit (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    action     TEXT NOT NULL,
    detail     TEXT NOT NULL,
    old_value  TEXT DEFAULT NULL,
    new_value  TEXT DEFAULT NULL,
    user_name  TEXT NOT NULL,
    user_role  TEXT NOT NULL,
    user_id    INTEGER DEFAULT NULL,
    ip_address TEXT DEFAULT NULL,
    type       TEXT NOT NULL DEFAULT 'update',
    created_at TEXT DEFAULT (datetime('now'))
  );
`);

// safe column additions for upgrades on existing DBs
function safeAdd(tbl, col, def) {
  try { db.exec(`ALTER TABLE ${tbl} ADD COLUMN ${col} ${def}`); } catch {}
}
safeAdd('requests','qty_requested','INTEGER'); safeAdd('requests','qty_approved','INTEGER DEFAULT NULL');
safeAdd('requests','admin_notes','TEXT DEFAULT ""'); safeAdd('requests','approved_by_id','INTEGER DEFAULT NULL');
safeAdd('requests','item_id','INTEGER DEFAULT NULL');
safeAdd('users','phone','TEXT DEFAULT ""'); safeAdd('users','last_login','TEXT DEFAULT NULL');
safeAdd('inventory','unit_cost','REAL DEFAULT 0');
safeAdd('audit','old_value','TEXT DEFAULT NULL'); safeAdd('audit','new_value','TEXT DEFAULT NULL');
safeAdd('audit','user_id','INTEGER DEFAULT NULL'); safeAdd('audit','ip_address','TEXT DEFAULT NULL');

// ════════════════════════════════════════════════════════════
// SEED DEFAULT DATA
// ════════════════════════════════════════════════════════════
function seedIfEmpty() {
  if (db.prepare('SELECT COUNT(*) as c FROM users').get().c > 0) return;
  console.log('🌱 Seeding demo data...');
  const h = p => bcrypt.hashSync(p, 10);

  const addDept = db.prepare('INSERT OR IGNORE INTO departments (name,code,head) VALUES (?,?,?)');
  [['Haematology','HAEM','Dr. Jane Wanjiku'],['Microbiology','MICRO','Dr. Kevin Mwangi'],
   ['Chemistry','CHEM','Dr. Esther Atieno'],['Blood Bank','BB','Dr. Brian Ochieng'],
   ['General','GEN','']].forEach(d => addDept.run(...d));

  const ap = db.prepare('INSERT OR IGNORE INTO permissions (role,resource,can_view,can_create,can_edit,can_delete,can_approve) VALUES (?,?,?,?,?,?,?)');
  [['admin','inventory',1,1,1,1,1],['admin','requests',1,1,1,1,1],['admin','users',1,1,1,1,0],
   ['admin','reports',1,1,0,0,0],['admin','audit',1,0,0,0,0],['admin','departments',1,1,1,0,0],
   ['staff','inventory',1,0,0,0,0],['staff','requests',1,1,0,0,0],['staff','users',0,0,0,0,0],
   ['staff','reports',0,0,0,0,0],['staff','audit',0,0,0,0,0]].forEach(r => ap.run(...r));

  const au = db.prepare('INSERT INTO users (name,email,password,role,dept,phone) VALUES (?,?,?,?,?,?)');
  au.run('Dr. Amara Osei','admin@lab.org',h('admin123'),'admin','All Departments','+254700000001');
  au.run('Jane Wanjiku',  'jane@lab.org', h('staff123'),'staff','Haematology',    '+254700000002');
  au.run('Kevin Mwangi',  'kevin@lab.org',h('staff123'),'staff','Microbiology',   '+254700000003');
  au.run('Esther Atieno', 'esther@lab.org',h('staff123'),'staff','Chemistry',     '+254700000004');
  au.run('Brian Ochieng', 'brian@lab.org',h('staff123'),'staff','Blood Bank',     '+254700000005');

  const ai = db.prepare('INSERT INTO inventory (name,category,dept,qty,min_qty,unit,supplier,unit_cost) VALUES (?,?,?,?,?,?,?,?)');
  [['EDTA Tubes 3mL','Consumables','Haematology',45,50,'pcs','MedSupply Ltd',1.50],
   ['Blood Agar Plates','Media','Microbiology',120,100,'pcs','BioPath Ltd',3.20],
   ['Sodium Citrate Tubes','Consumables','Haematology',18,30,'pcs','MedSupply Ltd',1.80],
   ['Glucose Reagent Kit','Reagents','Chemistry',8,10,'kits','ChemDiag Kenya',45.00],
   ['Crystal Violet Stain','Reagents','Microbiology',6,5,'bottles','BioPath Ltd',12.00],
   ['Creatinine Reagent','Reagents','Chemistry',22,15,'kits','ChemDiag Kenya',38.00],
   ['Haematology Diluent','Reagents','Haematology',3,10,'L','MedSupply Ltd',22.00],
   ['Petri Dishes 90mm','Consumables','Microbiology',200,80,'pcs','LabGen Africa',0.80],
   ['Pipette Tips 1mL','Consumables','Chemistry',400,200,'pcs','LabGen Africa',0.25],
   ['ABO Typing Antisera','Reagents','Blood Bank',5,8,'vials','Hemostat Ltd',65.00],
   ['Latex Gloves (M)','PPE','All',300,150,'pcs','SafeGuard Ltd',0.40],
   ['Immersion Oil','Reagents','Microbiology',2,4,'bottles','BioPath Ltd',18.00],
  ].forEach(r => ai.run(...r));

  const ar = db.prepare(`INSERT INTO requests (item_name,qty_requested,qty_approved,dept,user_id,user_name,status,notes,admin_notes,approved_by,approval_date,reject_reason) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`);
  ar.run('EDTA Tubes 3mL',100,null,'Haematology',2,'Jane Wanjiku','pending','Urgent – running low','',null,null,null);
  ar.run('Haematology Diluent',20,20,'Haematology',2,'Jane Wanjiku','approved','','Full quantity approved','Dr. Amara Osei','2026-03-15',null);
  ar.run('Glucose Reagent Kit',5,2,'Chemistry',4,'Esther Atieno','partial','Needed for patient workload','Only 2 kits available this cycle','Dr. Amara Osei','2026-03-14',null);
  ar.run('Blood Agar Plates',50,null,'Microbiology',3,'Kevin Mwangi','pending','Monthly restock','',null,null,null);
  ar.run('ABO Typing Antisera',10,10,'Blood Bank',5,'Brian Ochieng','approved','','Critical dept — approved in full','Dr. Amara Osei','2026-03-13',null);
  ar.run('Immersion Oil',3,1,'Microbiology',3,'Kevin Mwangi','partial','Need 3 bottles urgently','Only 1 in stock; remainder on order','Dr. Amara Osei','2026-03-12',null);

  const aa = db.prepare('INSERT INTO audit (action,detail,old_value,new_value,user_name,user_role,type) VALUES (?,?,?,?,?,?,?)');
  aa.run('System initialized','LabOS v2.0 database created',null,null,'System','system','update');
  aa.run('Full approval','Jane Wanjiku requested 20L Haematology Diluent — full qty released',null,'qty_released:20','Dr. Amara Osei','admin','approve');
  aa.run('Partial approval','Esther Atieno requested 5 Glucose Kits — released 2 of 5','qty_requested:5','qty_released:2','Dr. Amara Osei','admin','partial');
  aa.run('Full approval','Brian Ochieng requested 10 ABO Typing Antisera — approved','qty_requested:10','qty_released:10','Dr. Amara Osei','admin','approve');
  aa.run('Partial approval','Kevin Mwangi requested 3 Immersion Oil — released 1 of 3','qty_requested:3','qty_released:1','Dr. Amara Osei','admin','partial');
  console.log('✅ Seed complete');
}
seedIfEmpty();

// ════════════════════════════════════════════════════════════
// MIDDLEWARE
// ════════════════════════════════════════════════════════════
function auth(req, res, next) {
  const h = req.headers.authorization;
  if (!h || !h.startsWith('Bearer ')) return res.status(401).json({ error: 'Unauthorized' });
  try { req.user = jwt.verify(h.slice(7), JWT_SECRET); next(); }
  catch { res.status(401).json({ error: 'Session expired — please login again' }); }
}
function adminOnly(req, res, next) {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Admin access required' });
  next();
}
function logAudit(action, detail, user, type='update', oldVal=null, newVal=null) {
  db.prepare('INSERT INTO audit (action,detail,old_value,new_value,user_name,user_role,user_id,type) VALUES (?,?,?,?,?,?,?,?)')
    .run(action, detail, oldVal ? String(oldVal) : null, newVal ? String(newVal) : null, user.name, user.role, user.id||null, type);
}

// ════════════════════════════════════════════════════════════
// AUTH ROUTES
// ════════════════════════════════════════════════════════════
app.post('/api/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Email and password required' });
  const user = db.prepare('SELECT * FROM users WHERE email = ? AND active = 1').get(email.toLowerCase().trim());
  if (!user || !bcrypt.compareSync(password, user.password))
    return res.status(401).json({ error: 'Invalid email or password' });
  db.prepare("UPDATE users SET last_login = datetime('now') WHERE id = ?").run(user.id);
  const token = jwt.sign({ id:user.id, name:user.name, email:user.email, role:user.role, dept:user.dept }, JWT_SECRET, { expiresIn:'12h' });
  logAudit('Login', `${user.name} signed in`, user, 'user');
  res.json({ token, user: { id:user.id, name:user.name, email:user.email, role:user.role, dept:user.dept } });
});

app.post('/api/change-password', auth, (req, res) => {
  const { currentPassword, newPassword } = req.body;
  if (!newPassword || newPassword.length < 4) return res.status(400).json({ error: 'Password must be at least 4 characters' });
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  if (!bcrypt.compareSync(currentPassword, user.password))
    return res.status(400).json({ error: 'Current password is incorrect' });
  db.prepare('UPDATE users SET password = ? WHERE id = ?').run(bcrypt.hashSync(newPassword, 10), req.user.id);
  logAudit('Password changed', `${user.name} changed their password`, req.user, 'user');
  res.json({ ok: true });
});

// ════════════════════════════════════════════════════════════
// DEPARTMENTS
// ════════════════════════════════════════════════════════════
app.get('/api/departments', auth, (_req, res) => {
  res.json(db.prepare('SELECT * FROM departments ORDER BY name').all());
});
app.post('/api/departments', auth, adminOnly, (req, res) => {
  const { name, code, head } = req.body;
  if (!name || !code) return res.status(400).json({ error: 'Name and code required' });
  try {
    const r = db.prepare('INSERT INTO departments (name,code,head) VALUES (?,?,?)').run(name.trim(), code.trim().toUpperCase(), head||'');
    logAudit('Department added', `${name} (${code}) created`, req.user, 'update');
    res.json({ id: r.lastInsertRowid, name, code, head });
  } catch { res.status(400).json({ error: 'Department name or code already exists' }); }
});
app.put('/api/departments/:id', auth, adminOnly, (req, res) => {
  const { name, code, head, active } = req.body;
  const d = db.prepare('SELECT * FROM departments WHERE id = ?').get(req.params.id);
  if (!d) return res.status(404).json({ error: 'Not found' });
  db.prepare('UPDATE departments SET name=?,code=?,head=?,active=? WHERE id=?').run(name||d.name, code||d.code, head??d.head, active??d.active, d.id);
  logAudit('Department updated', `${d.name} updated`, req.user, 'update');
  res.json({ ok: true });
});

// ════════════════════════════════════════════════════════════
// PERMISSIONS
// ════════════════════════════════════════════════════════════
app.get('/api/permissions', auth, adminOnly, (_req, res) => {
  res.json(db.prepare('SELECT * FROM permissions ORDER BY role, resource').all());
});
app.put('/api/permissions/:id', auth, adminOnly, (req, res) => {
  const { can_view, can_create, can_edit, can_delete, can_approve } = req.body;
  const p = db.prepare('SELECT * FROM permissions WHERE id = ?').get(req.params.id);
  if (!p) return res.status(404).json({ error: 'Not found' });
  db.prepare('UPDATE permissions SET can_view=?,can_create=?,can_edit=?,can_delete=?,can_approve=? WHERE id=?')
    .run(can_view??p.can_view, can_create??p.can_create, can_edit??p.can_edit, can_delete??p.can_delete, can_approve??p.can_approve, p.id);
  logAudit('Permission updated', `${p.role}/${p.resource} permissions changed`, req.user, 'update');
  res.json({ ok: true });
});

// ════════════════════════════════════════════════════════════
// USERS
// ════════════════════════════════════════════════════════════
app.get('/api/users', auth, adminOnly, (_req, res) => {
  res.json(db.prepare('SELECT id,name,email,role,dept,phone,active,last_login,created_at FROM users ORDER BY name').all());
});
app.post('/api/users', auth, adminOnly, (req, res) => {
  const { name, email, password, role, dept, phone } = req.body;
  if (!name || !email || !password) return res.status(400).json({ error: 'Name, email and password required' });
  if (db.prepare('SELECT id FROM users WHERE email = ?').get(email.toLowerCase().trim()))
    return res.status(400).json({ error: 'A user with this email already exists' });
  const r = db.prepare('INSERT INTO users (name,email,password,role,dept,phone) VALUES (?,?,?,?,?,?)').run(name.trim(), email.toLowerCase().trim(), bcrypt.hashSync(password, 10), role||'staff', dept||'General', phone||'');
  logAudit('Staff added', `${name} added as ${role||'staff'} in ${dept||'General'}`, req.user, 'user');
  res.json({ id: r.lastInsertRowid, name, email, role, dept, active: 1 });
});
app.put('/api/users/:id', auth, adminOnly, (req, res) => {
  const { name, email, role, dept, phone, password } = req.body;
  const u = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
  if (!u) return res.status(404).json({ error: 'User not found' });
  const np = (password && password.length >= 4) ? bcrypt.hashSync(password, 10) : u.password;
  db.prepare('UPDATE users SET name=?,email=?,role=?,dept=?,phone=?,password=? WHERE id=?').run(name||u.name, email||u.email, role||u.role, dept||u.dept, phone??u.phone, np, u.id);
  logAudit('Staff updated', `${u.name} account updated`, req.user, 'user');
  res.json({ ok: true });
});
app.patch('/api/users/:id/toggle', auth, adminOnly, (req, res) => {
  const u = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
  if (!u) return res.status(404).json({ error: 'User not found' });
  const na = u.active ? 0 : 1;
  db.prepare('UPDATE users SET active = ? WHERE id = ?').run(na, u.id);
  logAudit(na ? 'Staff enabled' : 'Staff disabled', `${u.name} account ${na?'enabled':'disabled'}`, req.user, 'user');
  res.json({ ok: true, active: na });
});
app.delete('/api/users/:id', auth, adminOnly, (req, res) => {
  const u = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
  if (!u) return res.status(404).json({ error: 'User not found' });
  if (u.id === req.user.id) return res.status(400).json({ error: 'Cannot delete your own account' });
  db.prepare('DELETE FROM users WHERE id = ?').run(u.id);
  logAudit('Staff removed', `${u.name} (${u.email}) removed`, req.user, 'user');
  res.json({ ok: true });
});

// ════════════════════════════════════════════════════════════
// INVENTORY
// ════════════════════════════════════════════════════════════
app.get('/api/inventory', auth, (req, res) => {
  const u = req.user;
  res.json(u.role === 'admin'
    ? db.prepare('SELECT * FROM inventory ORDER BY dept, name').all()
    : db.prepare("SELECT * FROM inventory WHERE dept = ? OR dept = 'All' ORDER BY name").all(u.dept));
});
app.post('/api/inventory', auth, adminOnly, (req, res) => {
  const { name, category, dept, qty, min_qty, unit, supplier, unit_cost, notes } = req.body;
  if (!name || !dept || !unit) return res.status(400).json({ error: 'Name, department and unit required' });
  const r = db.prepare('INSERT INTO inventory (name,category,dept,qty,min_qty,unit,supplier,unit_cost,notes) VALUES (?,?,?,?,?,?,?,?,?)').run(name.trim(), category||'Consumables', dept, qty||0, min_qty||0, unit, supplier||'', unit_cost||0, notes||'');
  logAudit('Item added', `${name} added to ${dept} — initial qty: ${qty||0}`, req.user, 'update', null, `qty:${qty||0}`);
  res.json({ id: r.lastInsertRowid });
});
app.put('/api/inventory/:id', auth, adminOnly, (req, res) => {
  const item = db.prepare('SELECT * FROM inventory WHERE id = ?').get(req.params.id);
  if (!item) return res.status(404).json({ error: 'Item not found' });
  const { name, category, dept, qty, min_qty, unit, supplier, unit_cost, notes } = req.body;
  const newQty = qty ?? item.qty;
  db.prepare("UPDATE inventory SET name=?,category=?,dept=?,qty=?,min_qty=?,unit=?,supplier=?,unit_cost=?,notes=?,last_updated=date('now') WHERE id=?")
    .run(name||item.name, category||item.category, dept||item.dept, newQty, min_qty??item.min_qty, unit||item.unit, supplier??item.supplier, unit_cost??item.unit_cost, notes??item.notes, item.id);
  if (newQty !== item.qty)
    logAudit('Stock quantity changed', `${item.name}: ${item.qty} → ${newQty}`, req.user, 'update', `qty:${item.qty}`, `qty:${newQty}`);
  else
    logAudit('Item updated', `${item.name} details updated`, req.user, 'update');
  res.json({ ok: true });
});
app.delete('/api/inventory/:id', auth, adminOnly, (req, res) => {
  const item = db.prepare('SELECT * FROM inventory WHERE id = ?').get(req.params.id);
  if (!item) return res.status(404).json({ error: 'Item not found' });
  db.prepare('DELETE FROM inventory WHERE id = ?').run(item.id);
  logAudit('Item deleted', `${item.name} removed from ${item.dept}`, req.user, 'update');
  res.json({ ok: true });
});

// ════════════════════════════════════════════════════════════
// REQUESTS — full, partial, reject
// ════════════════════════════════════════════════════════════
app.get('/api/requests', auth, (req, res) => {
  const u = req.user;
  res.json(u.role === 'admin'
    ? db.prepare('SELECT * FROM requests ORDER BY created_at DESC').all()
    : db.prepare('SELECT * FROM requests WHERE user_id = ? ORDER BY created_at DESC').all(u.id));
});
app.post('/api/requests', auth, (req, res) => {
  const { item_name, item_id, qty_requested, notes, priority } = req.body;
  if (!item_name || !qty_requested || qty_requested < 1) return res.status(400).json({ error: 'Item and quantity required' });
  const u = req.user;
  const r = db.prepare('INSERT INTO requests (item_name,item_id,qty_requested,dept,user_id,user_name,notes,priority) VALUES (?,?,?,?,?,?,?,?)').run(item_name, item_id||null, qty_requested, u.dept, u.id, u.name, notes||'', priority||'Normal');
  logAudit('Request submitted', `${u.name} requested ${qty_requested} × ${item_name}`, u, 'request', null, `qty:${qty_requested}`);
  res.json({ id: r.lastInsertRowid, status: 'pending' });
});

// FULL APPROVE
app.patch('/api/requests/:id/approve', auth, adminOnly, (req, res) => {
  const r = db.prepare('SELECT * FROM requests WHERE id = ?').get(req.params.id);
  if (!r) return res.status(404).json({ error: 'Not found' });
  if (r.status !== 'pending') return res.status(400).json({ error: 'Request already processed' });
  const { admin_notes } = req.body;
  db.prepare("UPDATE requests SET status='approved',qty_approved=?,approved_by=?,approved_by_id=?,approval_date=date('now'),admin_notes=? WHERE id=?")
    .run(r.qty_requested, req.user.name, req.user.id, admin_notes||'', r.id);
  adjustStock(r, r.qty_requested);
  logAudit('Full approval', `${r.user_name} → ${r.qty_requested} × ${r.item_name} — full qty released`, req.user, 'approve', `qty_req:${r.qty_requested}`, `qty_released:${r.qty_requested}`);
  res.json({ ok: true });
});

// PARTIAL / ADJUSTED APPROVAL
app.patch('/api/requests/:id/partial', auth, adminOnly, (req, res) => {
  const r = db.prepare('SELECT * FROM requests WHERE id = ?').get(req.params.id);
  if (!r) return res.status(404).json({ error: 'Not found' });
  if (r.status !== 'pending') return res.status(400).json({ error: 'Request already processed' });
  const { qty_approved, admin_notes } = req.body;
  if (!qty_approved || qty_approved < 1) return res.status(400).json({ error: 'Approved qty must be at least 1' });
  if (qty_approved >= r.qty_requested) return res.status(400).json({ error: 'For full or greater qty, use full approval' });
  db.prepare("UPDATE requests SET status='partial',qty_approved=?,approved_by=?,approved_by_id=?,approval_date=date('now'),admin_notes=? WHERE id=?")
    .run(qty_approved, req.user.name, req.user.id, admin_notes||'', r.id);
  adjustStock(r, qty_approved);
  logAudit('Partial approval', `${r.user_name} requested ${r.qty_requested} × ${r.item_name} — released ${qty_approved} of ${r.qty_requested}`, req.user, 'partial', `qty_req:${r.qty_requested}`, `qty_released:${qty_approved}`);
  res.json({ ok: true });
});

// REJECT
app.patch('/api/requests/:id/reject', auth, adminOnly, (req, res) => {
  const r = db.prepare('SELECT * FROM requests WHERE id = ?').get(req.params.id);
  if (!r) return res.status(404).json({ error: 'Not found' });
  if (r.status !== 'pending') return res.status(400).json({ error: 'Request already processed' });
  const { reason, admin_notes } = req.body;
  db.prepare("UPDATE requests SET status='rejected',approved_by=?,approved_by_id=?,approval_date=date('now'),reject_reason=?,admin_notes=? WHERE id=?")
    .run(req.user.name, req.user.id, reason||'No reason given', admin_notes||reason||'', r.id);
  logAudit('Rejected request', `${r.user_name} requested ${r.qty_requested} × ${r.item_name} — rejected`, req.user, 'reject', `qty:${r.qty_requested}`, null);
  res.json({ ok: true });
});

function adjustStock(req, qty) {
  const item = req.item_id
    ? db.prepare('SELECT id FROM inventory WHERE id = ?').get(req.item_id)
    : db.prepare("SELECT id FROM inventory WHERE name = ? AND (dept = ? OR dept = 'All') LIMIT 1").get(req.item_name, req.dept);
  if (item) db.prepare("UPDATE inventory SET qty = qty + ?, last_updated = date('now') WHERE id = ?").run(qty, item.id);
}

// ════════════════════════════════════════════════════════════
// AUDIT
// ════════════════════════════════════════════════════════════
app.get('/api/audit', auth, adminOnly, (req, res) => {
  const { type, user, from, to, limit } = req.query;
  let sql = 'SELECT * FROM audit WHERE 1=1';
  const p = [];
  if (type) { sql += ' AND type = ?';          p.push(type); }
  if (user) { sql += ' AND user_name LIKE ?';  p.push('%'+user+'%'); }
  if (from) { sql += ' AND created_at >= ?';   p.push(from); }
  if (to)   { sql += ' AND created_at <= ?';   p.push(to+' 23:59:59'); }
  sql += ' ORDER BY created_at DESC LIMIT ?';
  p.push(parseInt(limit)||500);
  res.json(db.prepare(sql).all(...p));
});

// ════════════════════════════════════════════════════════════
// STATS & ALERTS
// ════════════════════════════════════════════════════════════
app.get('/api/stats', auth, (req, res) => {
  const u = req.user;
  const inv  = u.role==='admin' ? db.prepare('SELECT * FROM inventory').all() : db.prepare("SELECT * FROM inventory WHERE dept = ? OR dept = 'All'").all(u.dept);
  const reqs = u.role==='admin' ? db.prepare('SELECT * FROM requests').all() : db.prepare('SELECT * FROM requests WHERE user_id = ?').all(u.id);
  const pending = u.role==='admin'
    ? db.prepare("SELECT * FROM requests WHERE status='pending' ORDER BY created_at DESC").all()
    : db.prepare("SELECT * FROM requests WHERE user_id=? AND status='pending'").all(u.id);
  const low  = inv.filter(i => i.qty <= i.min_qty && i.min_qty > 0);
  const crit = inv.filter(i => i.qty <= Math.round(i.min_qty*0.3) && i.min_qty > 0);
  const totalValue = inv.reduce((s,i) => s + i.qty*(i.unit_cost||0), 0);

  const deptMap = {};
  inv.forEach(i => {
    if (!deptMap[i.dept]) deptMap[i.dept] = { items:0, units:0, low:0, value:0 };
    deptMap[i.dept].items++;
    deptMap[i.dept].units += i.qty;
    deptMap[i.dept].value  = Math.round((deptMap[i.dept].value + i.qty*(i.unit_cost||0))*100)/100;
    if (i.qty <= i.min_qty && i.min_qty > 0) deptMap[i.dept].low++;
  });

  res.json({
    totalItems: inv.length, totalUnits: inv.reduce((s,i)=>s+i.qty,0),
    totalValue: Math.round(totalValue*100)/100,
    lowStock: low.length, critStock: crit.length,
    pending: pending.length, totalRequests: reqs.length,
    approved: reqs.filter(r=>r.status==='approved').length,
    partial:  reqs.filter(r=>r.status==='partial').length,
    rejected: reqs.filter(r=>r.status==='rejected').length,
    lowStockItems: low, critStockItems: crit,
    activeStaff:   u.role==='admin' ? db.prepare("SELECT COUNT(*) as c FROM users WHERE role='staff' AND active=1").get().c : null,
    auditCount:    u.role==='admin' ? db.prepare('SELECT COUNT(*) as c FROM audit').get().c : null,
    recentActivity:u.role==='admin' ? db.prepare('SELECT * FROM audit ORDER BY created_at DESC LIMIT 6').all() : [],
    pendingList:   pending.slice(0,6),
    deptStats:     deptMap,
  });
});

app.get('/api/alerts', auth, adminOnly, (_req, res) => {
  const items = db.prepare('SELECT * FROM inventory WHERE qty <= min_qty AND min_qty > 0 ORDER BY (qty*1.0/min_qty) ASC').all();
  res.json({ count: items.length, items });
});

// ════════════════════════════════════════════════════════════
// CSV EXPORTS
// ════════════════════════════════════════════════════════════
app.get('/api/export/inventory.csv', auth, adminOnly, (_req, res) => {
  const rows = db.prepare('SELECT * FROM inventory ORDER BY dept,name').all();
  const csv = ['ID,Name,Category,Department,Qty,Min Qty,Unit,Unit Cost (KES),Supplier,Last Updated',
    ...rows.map(r=>`${r.id},"${r.name}",${r.category},${r.dept},${r.qty},${r.min_qty},${r.unit},${r.unit_cost||0},"${r.supplier||''}",${r.last_updated}`)
  ].join('\n');
  res.setHeader('Content-Disposition','attachment; filename=LabOS_Inventory.csv');
  res.setHeader('Content-Type','text/csv'); res.send(csv);
});

app.get('/api/export/requests.csv', auth, adminOnly, (_req, res) => {
  const rows = db.prepare('SELECT * FROM requests ORDER BY created_at DESC').all();
  const csv = ['ID,Item,Qty Requested,Qty Approved,Dept,Requested By,Date,Status,Reviewed By,Approval Date,Admin Notes,Reject Reason',
    ...rows.map(r=>`${r.id},"${r.item_name}",${r.qty_requested},${r.qty_approved??''},${r.dept},"${r.user_name}",${r.created_at},${r.status},"${r.approved_by||''}","${r.approval_date||''}","${(r.admin_notes||'').replace(/"/g,"'")}","${(r.reject_reason||'').replace(/"/g,"'")}"`)
  ].join('\n');
  res.setHeader('Content-Disposition','attachment; filename=LabOS_Requests.csv');
  res.setHeader('Content-Type','text/csv'); res.send(csv);
});

app.get('/api/export/audit.csv', auth, adminOnly, (_req, res) => {
  const rows = db.prepare('SELECT * FROM audit ORDER BY created_at DESC').all();
  const csv = ['ID,Action,Detail,Old Value,New Value,User,Role,Timestamp',
    ...rows.map(r=>`${r.id},"${r.action}","${(r.detail||'').replace(/"/g,"'")}","${r.old_value||''}","${r.new_value||''}","${r.user_name}",${r.user_role},${r.created_at}`)
  ].join('\n');
  res.setHeader('Content-Disposition','attachment; filename=LabOS_AuditLog.csv');
  res.setHeader('Content-Type','text/csv'); res.send(csv);
});

// ════════════════════════════════════════════════════════════
// EXCEL EXPORT
// ════════════════════════════════════════════════════════════
app.get('/api/export/excel', auth, adminOnly, async (req, res) => {
  if (!ExcelJS) return res.status(503).json({ error: 'Excel export not ready. Run: npm install — then restart server.' });
  const wb = new ExcelJS.Workbook();
  wb.creator = 'LabOS v2.0'; wb.created = new Date();
  const GREEN_HEX = 'FF0F9E72';

  function styledSheet(name, columns) {
    const ws = wb.addWorksheet(name);
    ws.columns = columns;
    const hr = ws.getRow(1);
    hr.font = { bold:true, color:{ argb:'FFFFFFFF' }, size:11 };
    hr.fill = { type:'pattern', pattern:'solid', fgColor:{ argb: GREEN_HEX } };
    hr.alignment = { vertical:'middle', horizontal:'center' };
    hr.height = 22;
    return ws;
  }

  const inv  = db.prepare('SELECT * FROM inventory ORDER BY dept,name').all();
  const reqs = db.prepare('SELECT * FROM requests ORDER BY created_at DESC').all();
  const audit= db.prepare('SELECT * FROM audit ORDER BY created_at DESC LIMIT 1000').all();

  // Sheet 1 — Inventory
  const ws1 = styledSheet('Inventory', [
    {header:'ID',key:'id',width:6},{header:'Item Name',key:'name',width:28},{header:'Category',key:'category',width:16},
    {header:'Department',key:'dept',width:16},{header:'Qty',key:'qty',width:8},{header:'Min Qty',key:'min_qty',width:10},
    {header:'Unit',key:'unit',width:10},{header:'Unit Cost (KES)',key:'unit_cost',width:16},
    {header:'Total Value (KES)',key:'total_val',width:18},{header:'Status',key:'status',width:12},
    {header:'Supplier',key:'supplier',width:22},{header:'Last Updated',key:'last_updated',width:16},
  ]);
  let totalVal = 0;
  inv.forEach(i => {
    const tv = i.qty*(i.unit_cost||0);
    totalVal += tv;
    const crit = i.qty <= Math.round(i.min_qty*0.3) && i.min_qty>0;
    const low  = i.qty <= i.min_qty && i.min_qty>0;
    const row = ws1.addRow({ ...i, total_val: Math.round(tv*100)/100, status: crit?'CRITICAL':low?'LOW':'OK' });
    const color = crit?'FFC13030':low?'FFC47A10':'FF2E7D32';
    row.getCell('qty').font    = { bold: low||crit, color:{ argb: color } };
    row.getCell('status').font = { bold:true, color:{ argb: color } };
    if ((row.number-1) % 2 === 0) row.fill = { type:'pattern', pattern:'solid', fgColor:{ argb:'FFF7F8FA' } };
  });
  ws1.addRow([]);
  const totRow = ws1.addRow({ name:'TOTAL INVENTORY VALUE (KES)', total_val: Math.round(totalVal*100)/100 });
  totRow.font = { bold:true }; totRow.getCell('name').alignment = { horizontal:'right' };

  // Sheet 2 — Requests
  const ws2 = styledSheet('Requests', [
    {header:'ID',key:'id',width:6},{header:'Item',key:'item_name',width:26},{header:'Qty Requested',key:'qty_requested',width:14},
    {header:'Qty Approved',key:'qty_approved',width:14},{header:'Dept',key:'dept',width:14},
    {header:'Requested By',key:'user_name',width:18},{header:'Date',key:'created_at',width:18},
    {header:'Status',key:'status',width:12},{header:'Reviewed By',key:'approved_by',width:20},
    {header:'Admin Notes',key:'admin_notes',width:34},
  ]);
  reqs.forEach((r,idx) => {
    const row = ws2.addRow({ ...r, qty_approved: r.qty_approved??'—', approved_by: r.approved_by||'Pending', admin_notes: r.admin_notes||r.reject_reason||'' });
    const colorMap = { approved:'FF2E7D32', partial:'FFC47A10', rejected:'FFC13030', pending:'FF888780' };
    row.getCell('status').font = { bold:true, color:{ argb: colorMap[r.status]||'FF888780' } };
    if (idx%2===0) row.fill = { type:'pattern', pattern:'solid', fgColor:{ argb:'FFF7F8FA' } };
  });

  // Sheet 3 — Dept Summary
  const ws3 = styledSheet('Department Summary', [
    {header:'Department',key:'dept',width:20},{header:'Total Items',key:'items',width:14},
    {header:'Total Units',key:'units',width:14},{header:'Low Stock Items',key:'low',width:16},
    {header:'Total Value (KES)',key:'value',width:20},
  ]);
  ['Haematology','Microbiology','Chemistry','Blood Bank','All'].forEach(d => {
    const di = inv.filter(i=>i.dept===d);
    const row = ws3.addRow({ dept:d, items:di.length, units:di.reduce((s,i)=>s+i.qty,0), low:di.filter(i=>i.qty<=i.min_qty&&i.min_qty>0).length, value: di.reduce((s,i)=>s+i.qty*(i.unit_cost||0),0).toFixed(2) });
    if (row.getCell('low').value > 0) row.getCell('low').font = { bold:true, color:{ argb:'FFC13030' } };
  });

  // Sheet 4 — Audit
  const ws4 = styledSheet('Audit Log', [
    {header:'ID',key:'id',width:6},{header:'Action',key:'action',width:22},{header:'Detail',key:'detail',width:50},
    {header:'Old Value',key:'old_value',width:16},{header:'New Value',key:'new_value',width:16},
    {header:'User',key:'user_name',width:20},{header:'Role',key:'user_role',width:10},{header:'Timestamp',key:'created_at',width:22},
  ]);
  audit.forEach(a => ws4.addRow({ ...a, old_value: a.old_value||'—', new_value: a.new_value||'—' }));

  res.setHeader('Content-Disposition','attachment; filename=LabOS_FullReport.xlsx');
  res.setHeader('Content-Type','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  await wb.xlsx.write(res);
  res.end();
});

// ════════════════════════════════════════════════════════════
// PDF EXPORT
// ════════════════════════════════════════════════════════════
app.get('/api/export/pdf', auth, adminOnly, (req, res) => {
  if (!PDFDocument) return res.status(503).json({ error: 'PDF export not ready. Run: npm install — then restart server.' });

  const doc = new PDFDocument({ margin:40, size:'A4' });
  res.setHeader('Content-Disposition','attachment; filename=LabOS_Report.pdf');
  res.setHeader('Content-Type','application/pdf');
  doc.pipe(res);

  const inv  = db.prepare('SELECT * FROM inventory ORDER BY dept,name').all();
  const reqs = db.prepare('SELECT * FROM requests ORDER BY created_at DESC LIMIT 50').all();
  const GREEN='#0f9e72', RED='#c13030', AMBER='#c47a10', DARK='#1a1d23', GRAY='#5a6272', LGRAY='#e2e5ea', PARTIAL='#6b3fa0';

  // header banner
  doc.rect(0,0,doc.page.width,110).fill(GREEN);
  doc.fillColor('#fff').fontSize(26).font('Helvetica-Bold').text('LabOS', 40, 28);
  doc.fontSize(12).font('Helvetica').text('Lab Inventory Management System — Full Report', 40, 62);
  doc.fontSize(9).text(`Generated: ${new Date().toLocaleString()}   |   Confidential Hospital Document`, 40, 84);
  doc.fillColor(DARK);

  // summary stats
  const low   = inv.filter(i=>i.qty<=i.min_qty&&i.min_qty>0);
  const crit  = inv.filter(i=>i.qty<=Math.round(i.min_qty*0.3)&&i.min_qty>0);
  const totV  = inv.reduce((s,i)=>s+i.qty*(i.unit_cost||0),0);
  const pend  = reqs.filter(r=>r.status==='pending').length;
  const partl = reqs.filter(r=>r.status==='partial').length;
  const appr  = reqs.filter(r=>r.status==='approved').length;

  function statBox(x, y, label, val, color) {
    doc.rect(x,y,108,52).lineWidth(1).strokeColor(LGRAY).stroke();
    doc.fontSize(8).fillColor(GRAY).text(label, x+7, y+7, {width:94});
    doc.fontSize(19).font('Helvetica-Bold').fillColor(color||DARK).text(String(val), x+7, y+20);
    doc.font('Helvetica').fillColor(DARK);
  }
  statBox(40, 130, 'Total Items',    inv.length,  GREEN);
  statBox(158,130, 'Low Stock',      low.length,  low.length?RED:GREEN);
  statBox(276,130, 'Critical',       crit.length, crit.length?RED:GREEN);
  statBox(394,130, 'Pending Req.',   pend,        pend?AMBER:GREEN);
  doc.fontSize(9).fillColor(GRAY).text(`Total Value: KES ${totV.toLocaleString(undefined,{minimumFractionDigits:2})}   |   Approved: ${appr}   Partial: ${partl}   Pending: ${pend}`, 40, 194);

  // inventory table
  let y = 216;
  doc.fontSize(12).font('Helvetica-Bold').fillColor(DARK).text('Inventory Status', 40, y); y+=18;
  const ic = [108,68,58,42,42,48,52,67];
  const ih = ['Item Name','Department','Category','Qty','Min','Unit','Status','Supplier'];
  doc.rect(40,y,515,18).fill(GREEN);
  let cx=40;
  ih.forEach((h,i)=>{doc.fillColor('#fff').fontSize(7.5).font('Helvetica-Bold').text(h,cx+3,y+5,{width:ic[i]-4,ellipsis:true});cx+=ic[i];});
  y+=18;
  inv.forEach((item,idx)=>{
    if(y>730){doc.addPage();y=40;}
    const isCrit=item.qty<=Math.round(item.min_qty*0.3)&&item.min_qty>0;
    const isLow=item.qty<=item.min_qty&&item.min_qty>0;
    if(idx%2===0) doc.rect(40,y,515,14).fill('#f7f8fa');
    const st=isCrit?'CRITICAL':isLow?'LOW':'OK';
    const sc=isCrit?RED:isLow?AMBER:GREEN;
    cx=40;
    [item.name,item.dept,item.category,item.qty,item.min_qty,item.unit,st,item.supplier||'—'].forEach((v,i)=>{
      doc.fillColor(i===6?sc:DARK).fontSize(7).font(i===6?'Helvetica-Bold':'Helvetica').text(String(v??''),cx+3,y+4,{width:ic[i]-4,ellipsis:true});cx+=ic[i];
    });
    y+=14;
  });

  // requests table
  if(y>640){doc.addPage();y=40;} else y+=20;
  doc.fontSize(12).font('Helvetica-Bold').fillColor(DARK).text('Requests Summary (last 50)', 40, y); y+=18;
  const rc=[112,50,52,70,78,58,55];
  const rh=['Item','Req Qty','Appr Qty','Requested By','Reviewed By','Date','Status'];
  doc.rect(40,y,515,18).fill(GREEN);
  cx=40;
  rh.forEach((h,i)=>{doc.fillColor('#fff').fontSize(7.5).font('Helvetica-Bold').text(h,cx+3,y+5,{width:rc[i]-4,ellipsis:true});cx+=rc[i];});
  y+=18;
  reqs.forEach((r,idx)=>{
    if(y>750){doc.addPage();y=40;}
    const colorMap={approved:GREEN,partial:PARTIAL,rejected:RED,pending:GRAY};
    const sc2=colorMap[r.status]||GRAY;
    if(idx%2===0) doc.rect(40,y,515,14).fill('#f7f8fa');
    cx=40;
    [r.item_name,r.qty_requested,r.qty_approved??'—',r.user_name,r.approved_by||'Pending',(r.approval_date||r.created_at||'').split(' ')[0]||'—',r.status.toUpperCase()].forEach((v,i)=>{
      doc.fillColor(i===6?sc2:DARK).fontSize(7).font(i===6?'Helvetica-Bold':'Helvetica').text(String(v??''),cx+3,y+3,{width:rc[i]-4,ellipsis:true});cx+=rc[i];
    });
    y+=14;
  });

  // footer
  doc.fontSize(8).fillColor(GRAY).text(`LabOS v2.0 — Confidential Hospital Document — Printed ${new Date().toLocaleDateString()}`, 40, 800, {align:'center',width:515});
  doc.end();
});

// ════════════════════════════════════════════════════════════
// SPA FALLBACK
// ════════════════════════════════════════════════════════════
app.get('*', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

// ════════════════════════════════════════════════════════════
// START
// ════════════════════════════════════════════════════════════
app.listen(PORT, '0.0.0.0', () => {
  const ips = Object.values(os.networkInterfaces()).flat().filter(n=>n.family==='IPv4'&&!n.internal).map(n=>n.address);
  console.log('\n╔══════════════════════════════════════════════════════════╗');
  console.log('║         LabOS v2.0 — Lab Inventory System                ║');
  console.log('╠══════════════════════════════════════════════════════════╣');
  console.log(`║  Local:    http://localhost:${PORT}                          ║`);
  ips.forEach(ip=>console.log(`║  Network:  http://${ip}:${PORT}  ← share with staff ║`));
  console.log('╠══════════════════════════════════════════════════════════╣');
  console.log('║  Admin:  admin@lab.org / admin123                        ║');
  console.log('║  Staff:  jane@lab.org  / staff123                        ║');
  console.log('╚══════════════════════════════════════════════════════════╝\n');
  if (!PDFDocument) console.log('⚠  PDF export: run  npm install  to enable');
  if (!ExcelJS)     console.log('⚠  Excel export: run  npm install  to enable');
});
