@echo off
echo.
echo  ================================================
echo   LabOS - Lab Inventory Management System
echo   Starting server...
echo  ================================================
echo.

:: Check if Node.js is installed
where node >nul 2>&1
if %errorlevel% neq 0 (
  echo  ERROR: Node.js is not installed!
  echo.
  echo  Please install Node.js from: https://nodejs.org
  echo  Download the LTS version and run the installer.
  echo  Then double-click this file again.
  echo.
  pause
  exit /b 1
)

:: Install dependencies if needed
if not exist "node_modules" (
  echo  Installing dependencies for the first time...
  echo  This only happens once. Please wait...
  echo.
  call npm install
  echo.
)

:: Create data directory if needed
if not exist "data" mkdir data

echo  Starting LabOS server...
echo  Keep this window open while using the system.
echo.
node server.js

pause
