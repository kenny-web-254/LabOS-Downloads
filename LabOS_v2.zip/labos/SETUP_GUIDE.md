# LabOS — Lab Inventory Management System
## Setup Guide for Hospital LAN Deployment

---

## What You Need (ONE computer acts as the server)

- Any computer that is **always on** during working hours
- **Node.js** installed (free, one-time download)
- Connected to the hospital's local network (LAN/WiFi)

All other computers **just need a web browser** — nothing to install on them.

---

## STEP 1: Install Node.js (One-time setup)

1. Go to **https://nodejs.org** on the server computer
2. Download the **LTS version** (the green button)
3. Run the installer — click **Next** through everything, keep all defaults
4. When done, you're ready

---

## STEP 2: Set Up LabOS

1. Copy the **labos** folder to the server computer
   - Recommended location: `C:\LabOS\` (Windows) or `/home/labos/` (Linux/Mac)
2. That's it — no other setup needed

---

## STEP 3: Start the Server

### On Windows:
Double-click **`START_SERVER.bat`**

The first time it runs, it will automatically install required packages (takes ~1 minute).
After that it starts instantly.

### On Mac/Linux:
Open Terminal in the labos folder and run:
```bash
chmod +x start_server.sh
./start_server.sh
```

---

## STEP 4: Access from Any Computer on the Network

When the server starts, it will show you something like this:

```
╔══════════════════════════════════════════════════════╗
║           LabOS — Lab Inventory System               ║
╠══════════════════════════════════════════════════════╣
║  Local:    http://localhost:3000                     ║
║  Network:  http://192.168.1.45:3000                 ║
╚══════════════════════════════════════════════════════╝
```

**Share the Network address** (e.g. `http://192.168.1.45:3000`) with all lab staff.

They just open their browser and go to that address. **No installation needed on their computers.**

---

## Default Login Credentials

| Name | Email | Password | Role | Department |
|------|-------|----------|------|------------|
| Dr. Amara Osei | admin@lab.org | admin123 | Admin | All |
| Jane Wanjiku | jane@lab.org | staff123 | Staff | Haematology |
| Kevin Mwangi | kevin@lab.org | staff123 | Staff | Microbiology |
| Esther Atieno | esther@lab.org | staff123 | Staff | Chemistry |
| Brian Ochieng | brian@lab.org | staff123 | Staff | Blood Bank |

> **Important:** Change these passwords after first login!
> Admin → Staff Management → Edit each user

---

## Finding Your Computer's IP Address

### Windows:
1. Press `Windows + R`, type `cmd`, press Enter
2. Type `ipconfig` and press Enter
3. Look for **IPv4 Address** under your network adapter
   - Usually looks like `192.168.x.x` or `10.x.x.x`

### Mac:
1. System Preferences → Network
2. Your IP is shown next to "Status: Connected"

### Linux:
```bash
hostname -I
```

---

## Keeping the Server Running

### Option A — Manual (simplest)
Just leave the terminal/command window open. The server runs as long as the window is open.

### Option B — Auto-start on Windows boot (recommended)
1. Press `Windows + R`, type `shell:startup`, press Enter
2. Create a shortcut to `START_SERVER.bat` in that folder
3. The server will now start automatically when Windows boots

### Option C — Windows Service (most reliable, for IT staff)
Install `pm2` globally:
```
npm install -g pm2
pm2 start server.js --name labos
pm2 startup
pm2 save
```

---

## Backing Up Your Data

Your database is a single file: **`data/labos.db`**

- Copy this file to a USB drive or shared folder regularly
- Weekly backups are recommended
- To restore: replace the `labos.db` file and restart the server

You can also export CSV reports from the Reports page anytime.

---

## Firewall / Network Issues

If other computers can't connect:

### Windows Firewall:
1. Search for "Windows Defender Firewall"
2. Click "Allow an app through firewall"
3. Click "Allow another app" → Browse to `node.exe`
   (usually at `C:\Program Files\nodejs\node.exe`)
4. Check both Private and Public boxes → OK

Or run this in Command Prompt as Administrator:
```
netsh advfirewall firewall add rule name="LabOS" dir=in action=allow protocol=TCP localport=3000
```

---

## Project File Structure

```
labos/
├── server.js          ← Main server (runs the whole system)
├── package.json       ← Node.js configuration
├── START_SERVER.bat   ← Windows double-click starter
├── start_server.sh    ← Mac/Linux starter
├── data/
│   └── labos.db       ← SQLite database (all your data lives here)
└── public/
    └── index.html     ← The web app (served to all browsers)
```

---

## Troubleshooting

**"Cannot find module" error**
→ Run `npm install` in the labos folder

**"Port 3000 is already in use"**
→ Either close the other LabOS window, or change the port:
  Edit `server.js`, find `const PORT = 3000` and change to `3001`

**Other computers show "This site can't be reached"**
→ Check firewall settings (see above)
→ Make sure you're using the correct IP address
→ Try `http://` not `https://`

**Data disappeared / database corrupted**
→ Restore from your backup: replace `data/labos.db` and restart

**"node is not recognized"**
→ Node.js isn't installed — download from nodejs.org

---

## Free Online Deployment (Optional)

If you want staff to access LabOS from outside the hospital:

### Render.com (Completely free, beginner-friendly)
1. Create a free account at **render.com**
2. Click **New → Web Service**
3. Connect your GitHub account and upload the labos folder
4. Set:
   - Build command: `npm install`
   - Start command: `node server.js`
5. Click Deploy

Your app gets a free URL like `https://labos-xxxx.onrender.com`

> Note: Free Render services sleep after 15min of inactivity (first load is slow).
> For always-on, use Railway.app — also free with a GitHub Student pack.

---

*LabOS v1.0.0 — Hospital Lab Inventory Management System*
