#!/bin/bash

echo ""
echo " ================================================"
echo "  LabOS - Lab Inventory Management System"
echo "  Starting server..."
echo " ================================================"
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
  echo " ERROR: Node.js is not installed!"
  echo ""
  echo " Please install Node.js from: https://nodejs.org"
  echo " Download the LTS version and run the installer."
  echo " Then run this script again."
  echo ""
  exit 1
fi

# Install dependencies if needed
if [ ! -d "node_modules" ]; then
  echo " Installing dependencies for the first time..."
  echo " This only happens once. Please wait..."
  echo ""
  npm install
  echo ""
fi

# Create data directory if needed
mkdir -p data

echo " Starting LabOS server..."
echo " Keep this terminal open while using the system."
echo ""
node server.js
